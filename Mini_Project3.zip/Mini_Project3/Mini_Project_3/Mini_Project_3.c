/**
 ===================================================================================================
 Name        : Mini Project 3

 Author      : Abdelrahman Diaa-Eldein

 Description : Fan Speed Controller with Temperature Sensor (Based on layered architecture mode)

 Date        : 28/5/2022
 ===================================================================================================
 **/


#include "Motor_Driver.h"      /*include the header file of the DC-Motor*/
#include "MY_LM35_Driver.h"    /*include the header file of the temperature sensor*/
#include "MY_LCD_Driver.h"     /*include the header file of the LCD*/
#include "MY_ADC_Driver.h"     /*include the header file of the ADC for only init function*/


/* Configuration Structure for ADC init function to setup both reference voltage
 * and the prescaler
 */

ADC_ConfigType config={INTERNAL,FCPU_8};

int main()
{
	uint8 temp=0;          /*variable to store sensor temperature value*/

	DcMotor_init();        /* initialize the DC-Motor Driver   */
	LCD_init();            /* initialize the LCD Driver   */
	ADC_init(&config);     /* initialize the ADC Driver   */


	/* Display this string "FAN IS " and "Temp =   C" only once on LCD  */
	LCD_moveCursor(0,3);
	LCD_displayString("FAN IS ");

	LCD_moveCursor(1,3);
	LCD_displayString("Temp =     C");


	while(1)
	{

		temp = LM35_getTemperature();  /* get temperature value and store it */

		if(temp<30)
		{
			DcMotor_rotate(STOP,0);    /* stop the motor if temp is lower than 30 */

			LCD_moveCursor(1,10);
			LCD_intgerToStringDisplay(temp);  /* Display temp value */

			/* In case the digital value is two or one digits print space in the next digit place*/
			LCD_displayCharacter(' ');

			LCD_moveCursor(0,11);
			LCD_displayString("OFF");    /* Display the motor state */

		}
		else if(temp>=120)
		{
			DcMotor_rotate(CW,100);      /* run the motor with max speed if temp is greater than 120 */

			LCD_moveCursor(1,10);
			LCD_intgerToStringDisplay(temp);  /* Display temp value */

			/* In case the digital value is two or one digits print space in the next digit place*/
			LCD_displayCharacter(' ');

			LCD_moveCursor(0,11);
			LCD_displayString("ON");    /* Display the motor state */

		}
		else if(temp>=90)
		{
			DcMotor_rotate(CW,75);     /* run the motor with 75% from its speed if temp is greater than 90 */

			LCD_moveCursor(1,10);
			LCD_intgerToStringDisplay(temp);  /* Display temp value */

			/* In case the digital value is two or one digits print space in the next digit place*/
			LCD_displayCharacter(' ');

			LCD_moveCursor(0,11);
			LCD_displayString("ON");   /* Display the motor state */

		}
		else if(temp>=60)
		{
			DcMotor_rotate(CW,50);    /* run the motor with 50% from its speed if temp is greater than 60 */

			LCD_moveCursor(1,10);
			LCD_intgerToStringDisplay(temp);  /* Display temp value */

			/* In case the digital value is two or one digits print space in the next digit place*/
			LCD_displayCharacter(' ');

			LCD_moveCursor(0,11);
			LCD_displayString("ON");  /* Display the motor state */

		}
		else if(temp>=30)
		{
			DcMotor_rotate(CW,25);   /* run the motor with 25% from its speed if temp is greater than 30 */

			LCD_moveCursor(1,10);
			LCD_intgerToStringDisplay(temp);  /* Display temp value */

			LCD_moveCursor(0,11);
			LCD_displayString("ON");  /* Display the motor state */

			/* In case the motor turns from OFF to ON  print space in the next digit place*/
			LCD_displayCharacter(' ');
		}
	}
}
