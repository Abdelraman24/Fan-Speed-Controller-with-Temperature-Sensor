/************************************************************************
 * Module: ADC
 *
 * File Name: MY_ADC_Driver.c
 *
 * Description: Source file for the ATmega16 ADC driver
 *
 * Author: Abdelrahman Diaa-Eldein Sayd
 *
 *  Created on: 22/5/2022
 *
 ***********************************************************************/


#include "MY_ADC_Driver.h"
#include "COMMON_MACROS.h"
#include <avr/io.h>


/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/


void ADC_init(const ADC_ConfigType* Config_Ptr)
{
	SET_BIT(ADCSRA,ADEN);

	ADMUX = (ADMUX & 0x3F) | ((Config_Ptr->ref_volt)<<6);

	ADCSRA = (ADCSRA & ~(0x07)) | (Config_Ptr->prescaler);

}


uint16 ADC_readChannel(uint8 pin_num)
{
	ADMUX= (ADMUX & ~(0X07)) |(pin_num);
	SET_BIT(ADCSRA,ADSC);
	while(BIT_IS_CLEAR(ADCSRA,ADIF));
	SET_BIT(ADCSRA,ADIF);
	return ADC;
}
