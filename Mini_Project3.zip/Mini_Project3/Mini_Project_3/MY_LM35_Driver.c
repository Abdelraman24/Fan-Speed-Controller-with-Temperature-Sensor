/************************************************************************
 * Module: LM35 SENSOR
 *
 * File Name: MY_LM35_Driver.c
 *
 * Description: Source file for the LM35 SENSOR driver
 *
 * Author: Abdelrahman Diaa-Eldein Sayd
 *
 *  Created on: 22/5/2022
 *
 ***********************************************************************/

#include "MY_LM35_Driver.h"
#include "MY_ADC_Driver.h"



/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/


uint8 LM35_getTemperature(void)
{
	uint16 adc_value=0;
	uint8 temp_value=0;
	adc_value = ADC_readChannel(SENSOR_CHANNEL_ID);
	temp_value = (uint8)(((uint32)adc_value * SENSOR_MAX_TEMPERATURE * 2.56) / (SENSOR_MAX_VOLT * ADC_MAXIMUM_VALUE));
    return temp_value;
}


