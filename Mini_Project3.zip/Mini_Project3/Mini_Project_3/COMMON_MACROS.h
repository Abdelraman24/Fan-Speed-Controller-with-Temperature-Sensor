/************************************************************************
 *  Module: My_COMMON_MACROS
 *
 *  File Name: COMMON_MACROS.h
 *
 *  Description: Commonly used Macros
 *
 *  Author: Abdelrahman Diaa-Eldein
 *
 *  Created on: 14/5/2022
 *
 ***********************************************************************/

#ifndef COMMON_MACROS_H_
#define COMMON_MACROS_H_


#define SET_BIT(REG,BIT)       (REG |=(1<<BIT))
#define CLEAR_BIT(REG,BIT)     (REG &=(~(1<<BIT)))
#define TOGGLE_BIT(REG,BIT)    (REG ^=(1<<BIT))


#define ROT_RIGHT(REG,NUM)     (REG = ( (REG>>NUM) | (REG<<8-NUM) ))
#define ROT_LEFT(REG,NUM)      (REG = ( (REG<<NUM) | (REG>>8-NUM) ))


#define BIT_IS_SET(REG,BIT)    (REG & (1<<BIT))
#define BIT_IS_CLEAR(REG,BIT)  ( !(REG & (1<<BIT)) )


#endif /* COMMON_MACROS_H_ */
