/************************************************************************
 * Module: LM35 SENSOR
 *
 * File Name: MY_LM35_Driver.h
 *
 * Description: header file for the LM35 SENSOR driver
 *
 * Author: Abdelrahman Diaa-Eldein Sayd
 *
 *  Created on: 22/5/2022
 *
 ***********************************************************************/

#ifndef MY_LM35_DRIVER_H_
#define MY_LM35_DRIVER_H_

#include "MY_std_types.h"


/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/


#define SENSOR_CHANNEL_ID         2
#define SENSOR_MAX_VOLT           1.5
#define SENSOR_MAX_TEMPERATURE    150



/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/


uint8 LM35_getTemperature(void);

#endif /* MY_LM35_DRIVER_H_ */
