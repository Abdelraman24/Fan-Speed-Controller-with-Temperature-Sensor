/************************************************************************
 * Module: ADC
 *
 * File Name: MY_ADC_Driver.h
 *
 * Description: header file for the ATmega16 ADC driver
 *
 * Author: Abdelrahman Diaa-Eldein Sayd
 *
 *  Created on: 22/5/2022
 *
 ***********************************************************************/

#ifndef MY_ADC_DRIVER_H_
#define MY_ADC_DRIVER_H_

#include "MY_std_types.h"

/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/

#define ADC_MAXIMUM_VALUE    1023

typedef enum{

	AREF,AVCC,RESERVED,INTERNAL

}ADC_ReferenceVoltage;


typedef enum{

	FCPU_2,FCPU_4=2,FCPU_8,FCPU_16,FCPU_32,FCPU_64,FCPU_128

}ADC_Prescaler;

typedef struct {

	ADC_ReferenceVoltage ref_volt;
	ADC_Prescaler prescaler;

}ADC_ConfigType;



/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/


void ADC_init(const ADC_ConfigType* Config_Ptr);

uint16 ADC_readChannel(uint8 pin_num);

#endif /* MY_ADC_DRIVER_H_ */
