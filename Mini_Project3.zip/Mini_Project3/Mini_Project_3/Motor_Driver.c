/************************************************************************
 * Module: DC Motor
 *
 * File Name: Motor_Driver.c
 *
 * Description: Source file for DC Motor driver
 *
 * Author: Abdelrahman Diaa-Eldein Sayd
 *
 *  Created on: 27/5/2022
 *
 ***********************************************************************/

#include "Motor_Driver.h"
#include "MY_GPIO_Driver.h"
#include "PWM_Timer0_Driver.h"




/*******************************************************************************
 *                      Functions Definitions                                  *
 *******************************************************************************/


void DcMotor_init(void)
{
	GPIO_setupPinDirection(MOTOR_PORT_ID, MOTOR_PIN1_ID ,PIN_OUTPUT);
	GPIO_setupPinDirection(MOTOR_PORT_ID, MOTOR_PIN2_ID ,PIN_OUTPUT);

	GPIO_writePin(MOTOR_PORT_ID,MOTOR_PIN1_ID , LOGIC_LOW);
	GPIO_writePin(MOTOR_PORT_ID ,MOTOR_PIN2_ID , LOGIC_LOW);
}

void DcMotor_rotate(DcMotor_State state,uint8 speed)
{
	 PWM_Timer0_Start(speed);


	 switch (state)
	 {
	 case STOP:
			GPIO_writePin(MOTOR_PORT_ID,MOTOR_PIN1_ID , LOGIC_LOW);
			GPIO_writePin(MOTOR_PORT_ID ,MOTOR_PIN2_ID , LOGIC_LOW);
	 break;
	 case CW:
			GPIO_writePin(MOTOR_PORT_ID,MOTOR_PIN1_ID , LOGIC_HIGH);
			GPIO_writePin(MOTOR_PORT_ID ,MOTOR_PIN2_ID , LOGIC_LOW);
	 break;
	 case A_CW:
			GPIO_writePin(MOTOR_PORT_ID,MOTOR_PIN1_ID , LOGIC_LOW);
			GPIO_writePin(MOTOR_PORT_ID ,MOTOR_PIN2_ID , LOGIC_HIGH);
	 break;
	 }


}
