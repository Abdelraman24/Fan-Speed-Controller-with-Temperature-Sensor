/************************************************************************
 * Module: Timer0 PWM mode
 *
 * File Name: PWM_Timer0_Driver.h
 *
 * Description: Header file for the ATmega16 Timer0 PWM mode driver
 *
 * Author: Abdelrahman Diaa-Eldein Sayd
 *
 *  Created on: 27/5/2022
 *
 ***********************************************************************/
#ifndef PWM_TIMER0_DRIVER_H_
#define PWM_TIMER0_DRIVER_H_

#include "MY_std_types.h"


/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/


#define MAX_ANALOG_OUTPUT  255

#define MAX_SPEED    100


/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/


void PWM_Timer0_Start(uint8 duty_cycle);



#endif /* PWM_TIMER0_DRIVER_H_ */
