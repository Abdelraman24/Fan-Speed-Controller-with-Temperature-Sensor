/************************************************************************
 * Module: DC Motor
 *
 * File Name: Motor_Driver.h
 *
 * Description: Header file for DC Motor driver
 *
 * Author: Abdelrahman Diaa-Eldein Sayd
 *
 *  Created on: 27/5/2022
 *
 ***********************************************************************/

#ifndef MOTOR_DRIVER_H_
#define MOTOR_DRIVER_H_

#include "MY_std_types.h"


/*******************************************************************************
 *                                Definitions                                  *
 *******************************************************************************/


#define MOTOR_PORT_ID      PORTB_ID

#define MOTOR_PIN1_ID      PIN4_ID

#define MOTOR_PIN2_ID      PIN5_ID


typedef enum {

	STOP,CW,A_CW

}DcMotor_State;



/*******************************************************************************
 *                      Functions Prototypes                                   *
 *******************************************************************************/


void DcMotor_init(void);

void DcMotor_rotate(DcMotor_State state,uint8 speed);


#endif /* MOTOR_DRIVER_H_ */
